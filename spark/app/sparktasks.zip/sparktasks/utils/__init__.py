# import logging.config
# from sparktasks.util import PathUtil
# import os
#
#
# log_conf = os.path.join(PathUtil.get_empyreal_path(),'sparktasks/logging.conf')
# log_path = os.path.join(PathUtil.get_empyreal_path(),'sparktasks/logs','covid_economy.log')
# logging.config.fileConfig(fname=log_conf,defaults={'logfilename': log_path})