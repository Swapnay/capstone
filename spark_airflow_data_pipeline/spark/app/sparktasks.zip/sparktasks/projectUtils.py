import configparser
CONFIG = configparser.RawConfigParser()
CONFIG_FILE = 'Config.cfg'
CONFIG.read(CONFIG_FILE)

def get_covid_usa_url():
    return CONFIG['COVID_US_DATA']

def get_covid_world_url():
    return CONFIG['COVID_WORD_DATA']
