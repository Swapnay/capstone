import requests
import pandas as pd
from os.path import isfile, join
import os, uuid
import json
# from toazureblob.sabutils import sablobutils
from pyspark.sql.types import *
from datetime import date
import logging
import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from sparktasks.utils.DBUtils import DButils
from sparktasks.utils.config import Config
from pyspark.sql.functions import year, month, dayofmonth, udf
from datetime import datetime



class UnemploymentData:
    start_year = "2007"
    end_year = date.today().year
    logger = logging.getLogger('pyspark')

    def __init__(self):
        self.DButils = DButils()
        self.config = Config()
        self.spark = SparkSession.builder.appName('Load housing').getOrCreate()
        self.spark.conf.set("spark.sql.crossJoin.enabled", "True")
        self.date_dim_df = self.DButils.load_from_db(self.spark, self.config.get_config('DIMS', 'HOUSING_DATE_DIM'))
        self.state_df = self.DButils.load_from_db(self.spark, self.config.get_config('DIMS', 'STATE_DIM'))
        self.unemployment_series = self.DButils.load_from_db(self.spark, self.config.get_config('DIMS', 'UNEMPLOYMENT_SERIES_DIM'))

    def flatten(self, df):
        complex_fields = dict([(field.name, field.dataType)
                               for field in df.schema.fields
                               if type(field.dataType) == ArrayType or type(field.dataType) == StructType])
        while len(complex_fields) != 0:
            col_name = list(complex_fields.keys())[0]
            print("Processing :" + col_name + " Type : " + str(type(complex_fields[col_name])))

            # if StructType then convert all sub element to columns.
            # i.e. flatten structs
            if (type(complex_fields[col_name]) == StructType):
                expanded = [F.col(col_name + '.' + k).alias(col_name + '_' + k) for k in [n.name for n in complex_fields[col_name]]]
                df = df.select("*", *expanded).drop(col_name)
            elif (type(complex_fields[col_name]) == ArrayType):
                df = df.withColumn(col_name, F.explode_outer(col_name))

            # recompute remaining Complex Fields in Schema
            complex_fields = dict([(field.name, field.dataType)
                                   for field in df.schema.fields
                                   if type(field.dataType) == ArrayType or type(field.dataType) == StructType])
        return df

    def get_data_dir(self):
        path1 = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
        data_fol = '{}{}'.format(path1, '/resources/data/')
        return data_fol

    def write_to_raw(self):
        try:
            data_dir = self.get_data_dir()
            for f in os.listdir(data_dir):
                file_path = join(data_dir, f)
                try:
                    if f.endswith("json"):
                        name = f.split(".")[0]
                        spark_df = self.spark.read.json("file:////" + file_path, multiLine=True)
                        flatten_df = self.flatten(spark_df)
                        split_udf = udf(lambda d: get_code(d), StringType())
                        flatten_df = flatten_df.withColumn('Results_series_seriesID', split_udf(flatten_df.Results_series_seriesID))
                        self.logger.debug("Writing data to azure %s", name)
                        self.DButils.save_to_db(flatten_df, self.config.get_config('RAW', name))
                except Exception as ex:
                    print(ex)
        except Exception as ex:
            self.logger.error(ex)

    def exec_query(self, unemployment_df, name):
        if name.lower() == 'unemployment_by_race':
            return self.get_data_by_race(unemployment_df, name)
        elif name.lower() == 'unemployment_by_education_level':
            return self.get_data_by_education(unemployment_df, name)
        elif name.lower() == 'unemployment_by_industry':
            return self.get_data_by_industry(unemployment_df, name)
        else:
            return self.get_data_by_state(unemployment_df, name)

    def get_data_by_state(self, unemployment_df, name):
        unemployment_df.createGlobalTempView(name)
        view_name = "{}.{}".format("global_temp", name)
        self.spark.read.table(view_name)

        query = "SELECT id as date_id ,area_text AS state,Results_series_data_value AS {} " \
                "FROM {} where area_type_code ={}  "
        union1 = query.format('unemployment_rate',view_name,  "\'A\'")
        total_df = self.spark.sql(union1)

        total_df = total_df.join(self.state_df, (total_df.state == self.state_df.name))
        total_df = total_df.withColumnRenamed('id', 'state_id')
        return total_df.select('date_id', 'state_id', 'unemployment_rate')

    def get_data_by_industry(self, unemployment_df, name):
        unemployment_df.createGlobalTempView(name)
        view_name = "{}.{}".format("global_temp", name)
        self.spark.read.table(view_name)

        query = "SELECT id ,area_text AS industry_type,Results_series_data_value AS {} " \
                "FROM {} where area_type_code =\'I\' AND stat_type = {} "
        union1 = query.format( 'unemployment', view_name, "\'U\'")
        total_df = self.spark.sql(union1)
        union2 = query.format( 'unemployment_rate', view_name, "\'R\'")
        rate_df = self.spark.sql(union2)

        total_df = total_df.withColumnRenamed('id', 'date_id') \
            .withColumnRenamed('industry_type', 'industry_type1')
        total_df = total_df.join(rate_df, (total_df.date_id == rate_df.id) & (total_df.industry_type1 == rate_df.industry_type))
        return total_df.select('date_id', 'industry_type', 'unemployment', 'unemployment_rate')

    def get_data_by_education(self, unemployment_df, name):
        unemployment_df.createGlobalTempView(name)
        view_name = "{}.{}".format("global_temp", name)
        self.spark.read.table(view_name)

        query = "SELECT id ,area_text AS education,Results_series_data_value AS {} " \
                "FROM {} where area_type_code =\'E\' AND stat_type = {} "

        union2 = query.format( 'participated',view_name, "\'P\'")
        participated_df = self.spark.sql(union2)
        query3 = query.format( 'participated_rate',view_name, "\'PR\'")
        participated_rate_DF = self.spark.sql(query3)
        query4 = query.format( 'unemployed',view_name, "\'U\'")
        unemployment_df = self.spark.sql(query4)
        query5 = query.format( 'unemployed_rate', view_name,"\'UR\'")
        unemployment_rate_df = self.spark.sql(query5)
        total_df = participated_df.withColumnRenamed('id', 'date_id') \
            .withColumnRenamed('education', 'education1')
        total_df = total_df.join(participated_rate_DF, (total_df.date_id == participated_rate_DF.id) &
                                 (total_df.education1 == participated_rate_DF.education))
        total_df = total_df.select('date_id', 'education', 'participated', 'participated_rate')
        total_df = total_df.withColumnRenamed('education', 'education1')
        total_df = total_df.join(unemployment_df, (unemployment_df.id == total_df.date_id) &
                  (unemployment_df.education == total_df.education1))
        unemp_df = total_df.select('date_id', 'education', 'participated', 'participated_rate', 'unemployed')
        final_unemp_df = unemp_df.withColumnRenamed('education', 'education1')
        final_unemp_df = final_unemp_df.join(unemployment_rate_df,(unemployment_rate_df.id == final_unemp_df.date_id) &
                                                                                    (unemployment_rate_df.education == final_unemp_df.education1))
        return final_unemp_df.select('date_id', 'education', 'participated', 'participated_rate', 'unemployed', 'unemployed_rate')

    def get_data_by_race(self, unemployment_df, name):
        unemployment_df.createGlobalTempView(name)
        view_name = "{}.{}".format("global_temp", name)
        self.spark.read.table(view_name)

        query = "SELECT id ,area_text AS race_type,Results_series_data_value AS {} " \
                "FROM {} where area_type_code =\'R\' AND stat_type = {} "
        union1 = query.format('civilian_noninstitutional', view_name, "\'T\'")
        total_df = self.spark.sql(union1)
        union2 = query.format('participated', view_name, "\'P\'")
        participated_df = self.spark.sql(union2)
        query3 = query.format('participated_rate', view_name, "\'PR\'")
        participated_rate_DF = self.spark.sql(query3)
        query4 = query.format('unemployed', view_name, "\'U\'")
        unemployment_df = self.spark.sql(query4)
        query5 = query.format('unemployed_rate', view_name, "\'UR\'")
        unemployment_rate_df = self.spark.sql(query5)
        total_df = total_df.withColumnRenamed('id', 'date_id') \
            .withColumnRenamed('race_type', 'area_text1')
        total_df = total_df.join(participated_df, (total_df.date_id == participated_df.id) & (total_df.area_text1 == participated_df.race_type))

        total_df = total_df.select('date_id', 'race_type', 'civilian_noninstitutional', 'participated')
        total_df.show()
        total_df = total_df.withColumnRenamed('race_type', 'area_text1')
        total_df = total_df.join(participated_rate_DF, (participated_rate_DF.id == total_df.date_id) &
                                 (participated_rate_DF.race_type == total_df.area_text1))
        total_df = total_df.select('date_id', 'race_type', 'civilian_noninstitutional', 'participated', 'participated_rate')
        total_df.show()
        final_df = total_df.withColumnRenamed('race_type', 'area_text1')
        final_df = final_df.join(unemployment_df, (unemployment_df.id == total_df.date_id)
                                 & (final_df.area_text1 == unemployment_df.race_type))
        unemp_df = final_df.select('date_id', 'race_type', 'civilian_noninstitutional', 'participated', 'participated_rate', 'unemployed')
        unemp_df.show()
        final_unemp_df = unemp_df.withColumnRenamed('race_type', 'area_text1')
        final_unemp_df = final_unemp_df.join(unemployment_rate_df, (unemployment_rate_df.id == unemp_df.date_id)
                                             & (final_unemp_df.area_text1 == unemployment_rate_df.race_type))

        return final_unemp_df.select('date_id', 'race_type', 'civilian_noninstitutional', 'participated', 'participated_rate', 'unemployed', 'unemployed_rate')

    def load_to_table(self):
        for name in dict(self.config.employment).keys():
            try:
                raw = self.config.get_config('RAW', name)
                fact_table = self.config.get_config('FACTS', name)
            except Exception as ex:
                print(ex)
                continue
            unemployment_df = self.DButils.load_from_db(self.spark, raw)
            unemployment_df.cache()
            # unemployment_df.createGlobalTempView(raw)
            # iew_name = "{}.{}".format("global_temp", raw)
            # self.spark.read.table(view_name)
            # unemployment_df = "SELECT Results_series_seriesID AS series_id,Results_series_data_period AS" \
            #                   " month_period,Results_series_data_value as data_value,Results_series_data_year as year_period, FROM {}".format(view_name)
            # #unemployment_df = self.spark.sql(unemployment_df)
            # unemployment_df.cache()

            split_udf = udf(lambda d: get_month(d), StringType())
            ue_df = unemployment_df.withColumn("umonth", split_udf(unemployment_df.Results_series_data_period))
            ue_df = ue_df.join(self.unemployment_series, (unemployment_df.Results_series_seriesID == self.unemployment_series.area_code))
            ue_df = ue_df.withColumnRenamed('id', 'series_id')
            unemployment_df = ue_df.join(self.date_dim_df, (self.date_dim_df.month == ue_df.umonth) & (self.date_dim_df.year == ue_df.Results_series_data_year))
            unemp_df = self.exec_query(unemployment_df, name)
            unemp_df = unemp_df.withColumn('submission_date', F.lit(datetime.now())).orderBy('date_id')
            max_date = unemp_df.agg(F.max('date_id')).first()[0]
            print(max_date)
            self.DButils.save_to_db(unemp_df, self.config.get_config('FACTS', name))
            df_date = self.date_dim_df.filter(self.date_dim_df.id == max_date)
            month = df_date.select("month").first()[0]
            year = df_date.select("year").first()[0]
            record_count = unemp_df.count()
            date_time_str = '{}-{}-{}'.format(year, month, '1')
            date_time_obj = datetime.strptime(date_time_str, "%Y-%m-%d")
            self.DButils.insert_update_metadata(name, record_count, date_time_obj, name)


UnemploymentData = UnemploymentData()
UnemploymentData.load_to_table()
