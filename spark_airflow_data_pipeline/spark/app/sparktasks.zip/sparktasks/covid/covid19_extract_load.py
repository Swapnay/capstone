from pyspark.sql import SparkSession
from pyspark import SparkFiles
import os
from sparktasks.utils.config import Config
from sparktasks.utils.DBUtils import DButils
import configparser
from pathlib import Path
import logging
from datetime import datetime
from pyspark.sql.functions import array, explode, struct, udf, when
from pyspark.sql.types import ArrayType, StructField, StructType, StringType, IntegerType, FloatType, DateType
from pyspark.sql.functions import year, month, dayofmonth
import  pyspark.sql.functions as f





def get_state_id(df, code):
    try:
        state_id = df[(df.code == code)].iloc[0]["id"]
        return state_id
    except Exception as ex:
        print(code)
        print(ex)
        return 60

    return df[(df.code == code)].iloc[0]["id"]


class Covid19etl:

    config = configparser.RawConfigParser()
    print(os.path.dirname(os.path.abspath(__file__)))
    print(os.path.abspath(__file__))
    config.read_file(open("/Users/syeruvala/Exercism/python/capstone_final_pipeline/spark_airflow_data_pipeline/spark/app/sparktasks/config.cfg"))
    mysql_user = config.get('MYSQL', 'USER')
    mysql_password = config.get('MYSQL', 'PASSWORD')

    def __init__(self):
        self.DButils = DButils()
        self.spark = SparkSession.builder.appName('Extract_Covid').getOrCreate()
        date_table = Covid19etl.config.get('DIMS', 'DATE_DIM')
        self.date_dim_df = self.DButils.load_from_db(self.spark, date_table)
        self.date_dim_df.createGlobalTempView(date_table)
        self.config = Config()
        state_dim = Covid19etl.config.get('DIMS', 'STATE_DIM')
        self.state_df = self.DButils.load_from_db(self.spark, state_dim)
        self.state_df.createGlobalTempView(state_dim)
        country_dim = Covid19etl.config.get('DIMS', 'COUNTRY_DETAILS_DIM')
        self.country_df = self.DButils.load_from_db(self.spark, country_dim)
        self.country_df.createGlobalTempView(country_dim)
        logging.info("initialization done")
        # Replace nagative values

    '''correctNegativeDiff = f.udf(lambda diff: 0 if diff < 0 else diff, LongType())

    df = df.withColumn('time_diff_1', correctNegativeDiff(df.time_diff_1))'''

    def extract(self):
        path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
        for name, value in dict(self.config.covid19_source).items():
            covid_usa = path + "/resources/data/" + name + ".csv"
            url = covid_usa
            file_name = os.path.basename(url)
            if (os.path.isfile(url)):
                self.spark.sparkContext.addFile(url)
                confirmed_us_df = self.spark.read.csv('file://' + url, header=True, inferSchema=True)
                confirmed_us_df.fillna(0)
                self.DButils.save_to_db(confirmed_us_df, Covid19etl.config.get('RAW', name))

    def transform_data(self):
        for name in dict(self.config.covid19_source).keys():
            pass

    def transform_load_world_data(self):
        self.spark.conf.set("spark.sql.execution.arrow.enabled", "False")
        name = "COVID_WORLD_DATA"
        covid_world_raw = Covid19etl.config.get('RAW', name)
        covid_world_df = self.DButils.load_from_db(self.spark, covid_world_raw)

        covid_world_df.createOrReplaceTempView(covid_world_raw)
        country_details_dim = Covid19etl.config.get('DIMS', 'COUNTRY_DETAILS_DIM')
        if (self.country_df.count() == 0):
            view_name = "{}.{}".format("global_temp", covid_world_raw)
            country_dim_df = self.spark.sql("SELECT iso_code,location, continent,population,population_density,median_age,aged_65_older,"
                                            " aged_70_older,gdp_per_capita,extreme_poverty,cardiovasc_death_rate,diabetes_prevalence,handwashing_facilities,"
                                            "hospital_beds_per_thousand,life_expectancy,human_development_index FROM {}".format(covid_world_raw))
            country_details_df = country_dim_df.withColumnRenamed("location", "country_name")
            self.country_df = country_details_df.select("iso_code", "country_name", 'continent', 'population', 'population_density', 'median_age', 'aged_65_older',
                                                        'aged_70_older', 'gdp_per_capita', 'extreme_poverty', 'cardiovasc_death_rate', 'diabetes_prevalence',
                                                        'handwashing_facilities', 'hospital_beds_per_thousand', 'life_expectancy', 'human_development_index') \
                .distinct()

            self.DButils.save_to_db(self.country_df, country_details_dim)
            self.country_df = self.DButils.load_from_db(self.spark, country_details_dim)

        covid_world_df = self.spark.sql("SELECT iso_code as country_code, date as submission_date,new_deaths, new_cases,total_cases,total_deaths,icu_patients,hosp_patients,weekly_icu_admissions,"
                                        "weekly_hosp_admissions,total_tests,new_tests,tests_per_case,positive_rate,tests_units,total_vaccinations,people_vaccinated,"
                                        "people_fully_vaccinated,new_vaccinations,stringency_index FROM {}".format(covid_world_raw))
        date_udf = udf(lambda d: convert_to_date_world(d), DateType())
        covid_world_df = covid_world_df.withColumn("submission_date", date_udf(covid_world_df.submission_date)) \
            .join(self.country_df, (self.country_df.iso_code == covid_world_df.country_code))
        #
        covid_world_dt_df = covid_world_df.withColumnRenamed("id", "country_id") \
            .withColumn("year", year(covid_world_df.submission_date)) \
            .withColumn("month", month(covid_world_df.submission_date)) \
            .withColumn("day", dayofmonth(covid_world_df.submission_date))
        covid_world = self.date_dim_df.join(covid_world_dt_df, (covid_world_dt_df.day == self.date_dim_df.day) & (covid_world_dt_df.month == self.date_dim_df.month) &
                                            (covid_world_dt_df.year == self.date_dim_df.year), how="inner")

        covid_world = covid_world.withColumnRenamed("id", "date_id")
        world_data_df = covid_world.select("date_id", "country_id", "submission_date", "new_cases", "total_cases", "total_deaths", "icu_patients", "hosp_patients", "weekly_icu_admissions",
                                           "weekly_hosp_admissions", "total_tests", "new_tests", "tests_per_case", "positive_rate", "tests_units", "total_vaccinations", "people_vaccinated",
                                           "people_fully_vaccinated", "new_vaccinations", "stringency_index")

        covid_world_fact = Covid19etl.config.get('FACTS', name)
        self.DButils.save_to_db(world_data_df, covid_world_fact)
        max_date = world_data_df.select(f.max("submission_date")).first()[0]
        record_count = world_data_df.count()
        self.DButils.insert_update_metadata(name.lower(), record_count, max_date, name.lower())

    def transform_load_usa_data(self):
        # spark = SparkSession.builder.appName('Transform').getOrCreate()
        self.spark.conf.set("spark.sql.execution.arrow.enabled", "False")
        name = "COVID_US_DATA"
        usa_df1 = self.DButils.load_from_db(self.spark, Covid19etl.config.get('RAW',name ))
        # usa_df.select("submission_date")
        usa_df1.cache()
        print(usa_df1.count())

        usa_df1.printSchema()
        self.date_dim_df.printSchema()
        # usa_df.join(self.date_dim_df,)

        date_udf = udf(lambda d: convert_to_date(d), DateType())

        '''.withColumn("state",state_udf(usa_df.state)) 
        .withColumn("date_id",date_id_udf(usa_df.submission_date))"date_id",'''

        usa_df = usa_df1.join(self.state_df, usa_df1.state == self.state_df.code)
        usa_df.cache()
        print(usa_df.count())
        usa_df.show(100)
        new_df = usa_df.withColumn("submit_date", date_udf(usa_df.submission_date)) \
            .withColumnRenamed("id", "state_id") \
            .withColumnRenamed("new_death", "new_deaths") \
            .withColumnRenamed("tot_death", "total_deaths") \
            .withColumnRenamed("new_case", "new_cases") \
            .withColumnRenamed("tot_cases", "total_cases")

        max_date = new_df.select(f.max("submit_date")).first()[0]

        # df = new_df.withColumn("state_id",state_udf(new_df.state_id)) \
        usa_df2 = new_df.withColumn("year", year(new_df.submit_date)) \
            .withColumn("month", month(new_df.submit_date)) \
            .withColumn("day", dayofmonth(new_df.submit_date))
        print(usa_df2.printSchema())
        usa_df2.cache()
        print(usa_df2.count())
        # usa_df2.show(20)
        self.date_dim_df.show(100)
        new_df2 = self.date_dim_df.join(usa_df2, (usa_df2.day == self.date_dim_df.day) & (usa_df2.month == self.date_dim_df.month) & (usa_df2.year == self.date_dim_df.year), how="inner")
        new_df2.show(100)
        new_df2.cache()
        print(new_df2.count())
        new_df1 = new_df2.withColumnRenamed("id", "date_id")
        usa_data_df = new_df1.select("date_id", "state_id", "submit_date", "new_deaths", "new_cases", "total_deaths", "total_cases")

        self.DButils.save_to_db(usa_data_df, Covid19etl.config.get('FACTS', name))
        record_count = usa_data_df.count()
        #covid_date = datetime.strptime(max_date, '%m-%d-%Y')
        self.DButils.insert_update_metadata(name.lower(), record_count, max_date, name.lower())

    def get_state_id(self, code):
        query = 'select id from state_dim WHERE code={} '.format(code)
        state_id = self.spark.sql(query)
        return state_id.id

        # date_udf = udf(lambda d: convert_date(d), DateType())
        # df = df.withColumn('date', date_udf(df['date']))
        # df = df.withColumnRenamed('Province/State', 'Province_State') \
        #     .withColumnRenamed('Country/Region', 'Country_Region') \
        #     .withColumnRenamed('Long', 'Long_')

print(Path().absolute())
covid19etl = Covid19etl()
covid19etl.extract()
covid19etl.transform_load_usa_data()
covid19etl.transform_load_world_data()
