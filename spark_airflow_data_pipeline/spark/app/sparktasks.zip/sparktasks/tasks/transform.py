class transform:

    def transform(self):
        pass